var exercise = {};

exercise.countRecords = function(data){
    return data.length;
};

exercise.countDistrictCrimes = function(data,district){
    var count = data.reduce(function(previous,current){
        if(current[19]===district){
            return ++previous;
        }
        return previous;
    },0);
    return count;
};

exercise.countPrimaryType = function(data,primaryType){
    var count = data.reduce(function(previous,current){
        if(current[13]===primaryType){
            return ++previous;
        }
        return previous;
    },0);
    return count;
};

exercise.countLocation = function(data,location){
    var count = data.reduce(function(previous,current){
        if(current[15]===location){
            return ++previous;
        }
        return previous;
    },0);
    return count;
};


exercise.buildLatLngPoint = function(crime){
    var point = {};
    point.latitude = crime[26];
    point.longitude = crime[28];
    return point;
};
