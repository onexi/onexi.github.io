# exercise-template-browser
Template for browser exercises
