var exercise = {};

// init data
var users  = [];

// populate data
exercise.populate = function(items){
    items.forEach(function(item){
        users.push(item);
    });
};

// get user count
exercise.count = function(){
    //-------------------
    //---- Your Code ----
    // 
    //  return format
    //    { count : 4 };    
    //-------------------    
};

// get all users
exercise.getUsers = function  (){
    //-------------------
    //---- Your Code ----
    //-------------------    
};

// get user using user id
exercise.getUserById = function (id){
    //-------------------
    //---- Your Code ----
    //-------------------    
};

// add a new user
exercise.addUser = function  (user){
    //-------------------
    //---- Your Code ----
    //-------------------    
};

// update user
exercise.updateUser = function (id,name){
    //-------------------
    //---- Your Code ----
    //-------------------    
};

// delete user from db
exercise.deleteUser = function (id){
    //-------------------
    //---- Your Code ----
    //-------------------    
};

module.exports = exercise;
