var exercise = require('./users_api.js');
var express  = require('express');
var app      = express();

// populate database
var users = [];
users.push({ 'email' : 'peter@mit.edu', 'name' : 'peter parker' });
users.push({ 'email' : 'bruce@mit.edu', 'name' : 'bruce wayne' });
users.push({ 'email' : 'clark@mit.edu', 'name' : 'clark kent' });
users.push({ 'email' : 'barry@mit.edu', 'name' : 'barry allen' });
exercise.populate(users);


app.get('/', function(req, res){ 
    res.send('Hello World!');
});

// number of users
app.get('/count', function(req, res){ 
    res.send(exercise.count());
});

// get all users
app.get('/getUsers', function(req, res){ 
    res.send(exercise.getUsers());
});

// get user using user id
app.get('/getUserById/:id', function(req, res){ 
    res.send(exercise.getUserById(req.params.id));
});

// add a new user
app.get('/addUser/:id/:name', function(req, res){ 
    res.send(exercise.addUser({'email':req.params.id,'name':req.params.name}));
});

// update user
app.get('/updateUser/:id/:name', function(req, res){ 
    res.send(exercise.updateUser(req.params.id,req.params.name));
});

// delete user from db
app.get('/deleteUser/:id', function(req, res){ 
    res.send(exercise.deleteUser(req.params.id));
});

app.listen(3001,function(){
	console.log('Running on port 3001!');
});