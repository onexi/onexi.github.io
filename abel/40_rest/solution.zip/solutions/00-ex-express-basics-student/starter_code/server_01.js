var express     = require('express');
var app         = express();

app.use(express.static('public'));

// used for form submissions
var bodyParser      = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// default path
app.get('/', function(req, res){ 
    res.send('Hello World!');
});

/* GET Registration Page */
app.get('/signup', function(req, res){
	res.redirect('/signup.html');
});

/* Handle Registration POST - body-parser module needed to parse form */
app.post('/signup', function(req, res){
	// YOUR CODE
});

// test POST with
// curl --data "username=value1&password=value2" http://localhost:3000/signup


// start server
app.listen(3000, function(){
	console.log('Listening on port 3000!');
});
