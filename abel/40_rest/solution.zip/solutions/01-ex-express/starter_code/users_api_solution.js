var exercise = {};

// init data
var users  = [];

// populate data
exercise.populate = function(items){
    items.forEach(function(item){
        users.push(item);
    });
};

// get user count
exercise.count = function(){
    return {count : users.length};    
};

// get all users
exercise.getUsers = function  (){
    return users;
};

// get user using user id
exercise.getUserById = function (id){
    var user = users.find(function(item){
        return id === item.email;
    });
    return user; 
};

// add a new user
exercise.addUser = function  (user){
    users.push(user);
    return users;
};

// update user
exercise.updateUser = function (id,name){
    var user = users.find(function(item){
        return id === item.email;
    });
    user.name = name;    
    return users;
};

// delete user from db
exercise.deleteUser = function (id){
    users = users.filter(function(item){
        return id !== item.email;
    });
    return users;
};

module.exports = exercise;
