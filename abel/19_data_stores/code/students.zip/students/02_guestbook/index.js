var express    = require('express');
var app        = express();
var createUser = require('./createUser.js');
var store      = [];

app.get('/', function(req,res){
	res.send(store);
});

app.get('/add/:length', function(req,res){
	// ------------------------------------------
	//  YOUR CODE
	//  create length new users, add to store
	//  var user = createUser();
	//  
	//  return number of new users
	// ------------------------------------------
});

var port = 3000;
app.listen(port, function(){
	console.log('Server running on port: ' + port);
})