
const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://<UserName>:<Password>@cluster0-pbjpc.mongodb.net/test?retryWrites=true";
const client = new MongoClient(uri, { useNewUrlParser: true });

client.connect(err => {
	// -----------------------------------
	//  YOUR CODE
	//
	//  - create database
	//  - create table
	//  - create multiple documents
	//  - add multiple documents to db
	//  - close connection
	// -----------------------------------
});
