 function generateUser () {

    // make name contextual to username and email
    var firstName = faker.name.firstName();
    var lastName = faker.name.lastName();
    var dob = faker.date.past(50, new Date("Sat Sep 20 1992 21:35:02 GMT+0200 (CEST)"));
    dob = dob.getFullYear() + "-" + (dob.getMonth()+1) + "-" + dob.getDate();  // First month is "1"
    var name = faker.name.findName(firstName, lastName);
    var address = faker.address.streetAddress();
    var cityStateZip = faker.address.city() + ", " + faker.address.stateAbbr() + " " + faker.address.zipCode();
    var locale = faker.locales[faker.locale].address.default_country || "";
    var phone = faker.phone.phoneNumber();
    var username = faker.internet.userName(firstName, lastName);
    var password = faker.internet.password();
    var email = faker.internet.email(firstName, lastName);

    return {
      firstName,
      lastName,
      dob,
      name,
      address,
      cityStateZip,
      locale,
      phone,
      username,
      password,
      email
    };
}