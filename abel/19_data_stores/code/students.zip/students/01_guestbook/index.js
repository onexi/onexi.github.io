var express = require('express');
var app     = express();
var store   = [];

app.get('/', function(req,res){
	res.send(store);
});

app.get('/add/:first/:last', function(req,res){
	// ------------------------------------------
	//  YOUR CODE
	//  create new object, add to store
	//  var obj = {first:first,last:last}
	//  
	//  return new object
	// ------------------------------------------
});

var port = 3000;
app.listen(port, function(){
	console.log('Server running on port: ' + port);
})