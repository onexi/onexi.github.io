var express = require('express');
var app     = express();
var store   = [];

app.get('/', function(req,res){
	res.send(store);
});

app.get('/add/:first/:last', function(req,res){
	var first = req.params.first;
	var last  = req.params.last;
	var obj   = {first,last};
	store.push(obj);
	res.send(obj);
});

var port = 3000;
app.listen(port, function(){
	console.log('Server running on port: ' + port);
})