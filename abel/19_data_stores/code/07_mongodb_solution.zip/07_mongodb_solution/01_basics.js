
const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://<UserName>:<Password>@cluster0-pbjpc.mongodb.net/test?retryWrites=true";
const client = new MongoClient(uri, { useNewUrlParser: true });

client.connect(err => {
	// get handle on database
	const db = client.db("test");

	// create documents table
	const collection = db.collection('documents');

	// insert some documents
	collection.insertMany([
		{a : 1}, {a : 2}, {a : 3}
	], function(err, result) {
		console.log("Inserted 3 documents into the collection");
		console.log(result);
	});

	client.close();
});
