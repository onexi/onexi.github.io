
const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://<UserName>:<Password>@cluster0-pbjpc.mongodb.net/test?retryWrites=true";
const client = new MongoClient(uri, { useNewUrlParser: true });

client.connect(err => {
	// get handle on database
	const db = client.db("test");

	// create documents table
	const collection = db.collection('documents');

	// insert some documents
	collection.insertMany([
		{a : 1}, {a : 2}, {a : 3}
	], function(err, result) {
		console.log("Inserted 3 documents into the collection");
		console.log(result);
	});

	// read documents
	collection.find({}).toArray(function(err, docs) {
		console.log("Found the following records");
		console.log(docs)
	});

	// query documents
	collection.find({'a': 3}).toArray(function(err, docs) {
		console.log("Found the following records");
		console.log(docs);
	});

	// update document
	collection.updateOne({ a : 2 }
		, { $set: { b : 1 } }, function(err, result) {
		console.log("Updated the document with the field a equal to 2");
		console.log(result);
	});

	// remove document
	collection.deleteOne({ a : 3 }, function(err, result) {
		console.log("Removed the document with the field a equal to 3");
		console.log(result);
	});

	client.close();
});
