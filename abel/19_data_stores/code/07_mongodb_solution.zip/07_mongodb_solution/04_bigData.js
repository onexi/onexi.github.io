var createUser = require('./createUser.js');
const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://<UserName>:<Password>@cluster0-pbjpc.mongodb.net/test?retryWrites=true";
const client = new MongoClient(uri, { useNewUrlParser: true });

client.connect(err => {
	// get handle on database
	const db = client.db("test");

	// create documents table
	const collection = db.collection('fakes');

	// create users
	var users = [];
	for (var i = 0; i < 1000; i++) {
		users.push(createUser());
	}

	// insert users
	collection.insertMany(
		users
	, function(err, result) {
		console.log("Inserted users documents into collection");
		console.log(result);
	});

	client.close();
});
