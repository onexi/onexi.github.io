var createUser = require('./createUser.js');
const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://<UserName>:<Password>@cluster0-pbjpc.mongodb.net/test?retryWrites=true";
const client = new MongoClient(uri, { useNewUrlParser: true });

client.connect(err => {
	// get handle on database
	const db = client.db("test");

	// create documents table
	const collection = db.collection('documents');


	collection.find({}).toArray(function(err, docs) {
		console.log("Found the following records");
		console.log(docs)
	});


	client.close();
});
