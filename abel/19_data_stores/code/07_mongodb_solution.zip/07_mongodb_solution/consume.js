var createUser = require('./createUser.js');

console.log(createUser());