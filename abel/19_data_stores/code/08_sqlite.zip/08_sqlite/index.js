var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('students.db');
 
db.serialize(function() {
  db.run("CREATE TABLE if not exists users (name TEXT, email TEXT)");
  db.run("INSERT into users(name,email) VALUES ('peter parker','parker@mit.edu')");
  db.run("INSERT into users(name,email) VALUES ('clark kent'  ,'clark@mit.edu')");

  console.log('----------- read data from table -----------'); 	
  db.all("SELECT * FROM users", function(err, rows) { 
    console.log(rows); 
  }); 

});
 
db.close();
