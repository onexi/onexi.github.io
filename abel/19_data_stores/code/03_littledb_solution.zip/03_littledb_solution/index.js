var express  = require('express');
var app      = express();
var createUser = require('./createUser.js');
var low      = require('lowdb');
var FileSync = require('lowdb/adapters/FileSync');
var adapter  = new FileSync('db.json');
var db       = low(adapter);
 
// Set some defaults
db.defaults({ users: [] }).write()
  
app.get('/add/:length', function(req,res){
    var length = req.params.length;
    for (var i = 0; i < length; i++) {
        var user = createUser();
        db.get('users')
            .push(user)
            .write()
    }
    res.send('added ' + length + ' users');
});

app.get('/', function(req,res){
    res.send(db.get('users').value());
});

app.listen(3000,function(){
    console.log('Server running on port: ' + 3000);
})