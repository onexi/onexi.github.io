var low     = require('lowdb');
var fs      = require('lowdb/adapters/FileSync');
var adapter = new fs('db.json');
var db      = low(adapter);

// init the data store
db.defaults({ posts: [] }).write();
var posts = db.get('posts');

// add post
var post1 = { title : 'Hello World!', id : '1', published : 'false'};
var post2 = { title : 'Boston Cool!', id : '2', published : 'true'};
var post3 = { title : 'Code Cancun!', id : '3', published : 'false'};
var post4 = { title : 'Code Madrid!', id : '4', published : 'true'};
posts.push(post1,post2,post3,post4).write();

// count posts
console.log('number of posts: ' + posts.size().value());
//console.log(posts.value()); 

// find all posts ids
console.log(posts.map('id').value()); 

// all matches of published false
console.log(posts.filter({published:'false'}).value()); 

// find post with published false
console.log(posts.find({title:'Code Madrid!'}).value()); 
