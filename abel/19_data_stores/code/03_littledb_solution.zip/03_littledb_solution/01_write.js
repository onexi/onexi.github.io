var low     = require('lowdb');
var fs      = require('lowdb/adapters/FileSync');
var adapter = new fs('db.json');
var db      = low(adapter);

// init the data store
db.defaults({ posts: [] }).write();

// add post
var date = new Date().toJSON();
var post = { title : 'Hello World!', date : new Date().toJSON()};
db.get('posts')
    .push(post)
    .write();