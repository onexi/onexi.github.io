var express    = require('express');
var app        = express();
var createUser = require('./createUser.js');
var store      = [];

app.get('/', function(req,res){
	res.send(store);
});

app.get('/add/:length', function(req,res){
	var length = req.params.length;
	for (var i = 0; i < length; i++) {
		var user = createUser();
		store.push(user);
	}
	res.send('added ' + length + ' users');
});

var port = 3000;
app.listen(port, function(){
	console.log('Server running on port: ' + port);
})