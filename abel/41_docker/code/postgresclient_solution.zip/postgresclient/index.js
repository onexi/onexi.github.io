var connectionString = 'postgresql://postgres:mysecretpassword@localhost:5432/postgres';
var { Client } = require('pg');
var client = new Client({
  connectionString: connectionString,
});

client.connect();

client.query('SELECT $1::text as message', ['Hello world!'], (err, res) => {
  console.log(err ? err.stack : res.rows[0].message); // Hello World!
  client.end();
});