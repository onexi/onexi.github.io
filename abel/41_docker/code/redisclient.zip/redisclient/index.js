var redis = require("redis"),
    client = redis.createClient();
 
// -----------------------------------
//  Your Code
//    1) connect to the database
//    2) read or write to database
// -----------------------------------
