var low     = require('lowdb');
var fs      = require('lowdb/adapters/FileSync');
var adapter = new fs('db.json');
var db 	    = low(adapter);

// Set some defaults
db.defaults({ posts: [], user: {} })
  .write();
 
// Add a post
db.get('posts')
  .push({ id: 1, title: 'lowdb is awesome'})
  .write();
 
// Set a user using Lodash shorthand syntax
db.set('user.name', 'typicode')
  .write();

// read
var result = db.get('posts')
  .find({ id: 1 })
  .value();

console.log(result);
