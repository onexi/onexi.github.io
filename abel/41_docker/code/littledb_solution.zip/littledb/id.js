var low     = require('lowdb');
var fs      = require('lowdb/adapters/FileSync');
var adapter = new fs('db.json');
var db 	    = low(adapter);
var shortid = require('shortid');

// Set some defaults
db.defaults({ posts: [], user: {} })
  .write();

// write
var postId = db
  .get('posts')
  .push({ id: shortid.generate(), title: shortid.generate() })
  .write()
  .id;
 
// read all
var all = db.get('posts').value();
console.log(all);

// get titles
var titles = db.get('posts')
  .map('title')
  .value();
console.log(titles);

// get number of posts
var number = db.get('posts')
  .size()
  .value();
console.log(number);  