var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
 
// Connection URL 
var url = 'mongodb://localhost:27017/myproject';

// -----------------------------------
//  Your Code
//  	1) connect to the database
//    	2) read or write to database
// -----------------------------------

