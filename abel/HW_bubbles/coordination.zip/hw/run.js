var exercise = require('./exercise.js');

var urls = [
    'http://student.mit.edu/catalog/m1a.html',
    'http://student.mit.edu/catalog/m1b.html',
    'http://student.mit.edu/catalog/m1c.html'
];

urls.forEach(function(url,i){

	var page = exercise.get(url);
	page.then(function(body){
		console.log(body);
		var filename = 'catalog/data' + i + '.txt';
		return exercise.save(body,filename);
	}).
	then(function(msg){
		console.log(msg);
	});

});
