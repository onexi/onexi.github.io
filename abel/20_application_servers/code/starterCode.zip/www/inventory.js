var seasons = new Array();
seasons[0] = "winter";
seasons[1] = "spring";
seasons[2] = "summer";
seasons[3] = "fall";


var categories = new Array();
categories[0] = "dairyEggs";
categories[1] = "fibers";
categories[2] = "flowers";
categories[3] = "fruits";
categories[4] = "grains";
categories[5] = "herbs";
categories[6] = "meatsLivestock";
categories[7] = "nutsSeeds";
categories[8] = "processed";
categories[9] = "specialtyProducts";
categories[10] = "sprouts";
categories[11] = "vegetables";


var dairyEggs = new Array();
dairyEggs[0] = "butter";
dairyEggs[1] = "buttermilk";
dairyEggs[2] = "cheese";
dairyEggs[3] = "eggs";
dairyEggs[4] = "goatCheese";
dairyEggs[5] = "goatMilk";
dairyEggs[6] = "goatYogurt";
dairyEggs[7] = "milk";
dairyEggs[8] = "rawMilk";
dairyEggs[9] = "yogurt";


var fibers = new Array();
fibers[0] = "alpaca";
fibers[1] = "angora";
fibers[2] = "cashmere";
fibers[3] = "llama";
fibers[4] = "mohair";
fibers[5] = "wool";


var flowers = new Array();
flowers[0] = "driedFlowers";
flowers[1] = "edibleFlowers";
flowers[2] = "freshFlowers";


var fruits = new Array();
fruits[0] = "apples";
fruits[1] = "apricots";
fruits[2] = "asianPears";
fruits[3] = "avocados";
fruits[4] = "bananas";
fruits[5] = "blackberries";
fruits[6] = "blueberries";
fruits[7] = "boysenberries";
fruits[8] = "cantaloupes";
fruits[9] = "cherimoyas";
fruits[10] = "cherries";
fruits[11] = "cranberries";
fruits[12] = "currants";
fruits[13] = "dates";
fruits[14] = "figs";
fruits[15] = "grapefruits";
fruits[16] = "grapes";
fruits[17] = "guavas";
fruits[18] = "kiwis";
fruits[19] = "kumquats";
fruits[20] = "lemons";
fruits[21] = "limes";
fruits[22] = "longan";
fruits[23] = "lychee";
fruits[24] = "mandarins";
fruits[25] = "mangos";
fruits[26] = "marionberries";
fruits[27] = "melons";
fruits[28] = "nectarines";
fruits[29] = "olives";
fruits[30] = "ollalieberries";
fruits[31] = "oranges";
fruits[32] = "papayas";
fruits[33] = "passionfruit";
fruits[34] = "peaches";
fruits[35] = "pears";
fruits[36] = "persimmons";
fruits[37] = "plums";
fruits[38] = "pomelos";
fruits[39] = "prunes";
fruits[40] = "quince";
fruits[41] = "raisins";
fruits[42] = "raspberries";
fruits[43] = "rhubarb";
fruits[44] = "strawberries";
fruits[45] = "tangerines";
fruits[46] = "tropicals";
fruits[47] = "watermelons";  


var grains = new Array();
grains[0] = "barley";
grains[1] = "buckwheat";
grains[2] = "corn";
grains[3] = "millet";
grains[4] = "oats";
grains[5] = "popcorn";
grains[6] = "rice";
grains[7] = "rye";
grains[8] = "soyBeans";
grains[9] = "spelt";
grains[10] = "wheat";


var herbs = new Array();
herbs[0] = "driedHerbs";
herbs[1] = "freshHerbs";
herbs[2] = "medicinalHerbs";
herbs[3] = "tobacco";


var meatsLivestock = new Array();
meatsLivestock[0] = "beef";
meatsLivestock[1] = "bison";
meatsLivestock[2] = "chicken";
meatsLivestock[3] = "duck";
meatsLivestock[4] = "emu";
meatsLivestock[5] = "fishSeafood";
meatsLivestock[6] = "gamebird";
meatsLivestock[7] = "geese";
meatsLivestock[8] = "goat";
meatsLivestock[9] = "jerky";
meatsLivestock[10] = "lamb";
meatsLivestock[11] = "ostrich";
meatsLivestock[12] = "pork";
meatsLivestock[13] = "rabbit";
meatsLivestock[14] = "squab";
meatsLivestock[15] = "turkey";
meatsLivestock[16] = "veal";
meatsLivestock[17] = "venison";


var nutsSeeds = new Array();
nutsSeeds[0] = "almonds";
nutsSeeds[1] = "chestnuts";
nutsSeeds[2] = "flax";
nutsSeeds[3] = "hazelnuts";
nutsSeeds[4] = "macadamias";
nutsSeeds[5] = "peanuts";
nutsSeeds[6] = "pecans";
nutsSeeds[7] = "pistachios";
nutsSeeds[8] = "sesameSeeds";
nutsSeeds[9] = "sunflowerSeeds";
nutsSeeds[10] = "walnuts";


var processed = new Array();
processed[0] = "bakedGoods";
processed[1] = "bathBody";
processed[2] = "beePollen";
processed[3] = "beer";
processed[4] = "beeswax";
processed[5] = "bread";
processed[6] = "cider";
processed[7] = "coffee";
processed[8] = "driedFruits";
processed[9] = "flour";
processed[10] = "honey";
processed[11] = "mapleSyrup";
processed[12] = "molasses";
processed[13] = "pastaSoups";
processed[14] = "petFood";
processed[15] = "pickles";
processed[16] = "preserves";
processed[17] = "pressedOil";
processed[18] = "soap";
processed[19] = "sodas";
processed[20] = "syrupNonMaple";
processed[21] = "teas";
processed[22] = "vinegar";
processed[23] = "wine";


var specialtyProducts = new Array();
specialtyProducts[0] = "christmasTrees";
specialtyProducts[1] = "christmasWreaths";
specialtyProducts[2] = "compostManure";
specialtyProducts[3] = "earthworms";
specialtyProducts[4] = "firewood";
specialtyProducts[5] = "gourds";
specialtyProducts[6] = "hayStraw";
specialtyProducts[7] = "leatherSheepskins";
specialtyProducts[8] = "luffa";
specialtyProducts[9] = "lumber";
specialtyProducts[10] = "plantsBeddingEtc";
specialtyProducts[11] = "seeds";


var sprouts = new Array();
sprouts[0] = "sprouts";   
sprouts[1] = "wheatGrass";   


var vegetables = new Array();
vegetables[0] = "artichoke";
vegetables[1] = "arugula";
vegetables[2] = "asparagus";
vegetables[3] = "beets";
vegetables[4] = "broccoli";
vegetables[5] = "brusselsSprouts";
vegetables[6] = "burdock";
vegetables[7] = "cabbage";
vegetables[8] = "carrots";
vegetables[9] = "cauliflower";
vegetables[10] = "celery";
vegetables[11] = "chineseGreens";
vegetables[12] = "collards";
vegetables[13] = "sweetCorn";
vegetables[14] = "cucumber";
vegetables[15] = "daikon";
vegetables[16] = "dryBeans";
vegetables[17] = "edamameSoybeans";
vegetables[18] = "eggplant";
vegetables[19] = "garlic";
vegetables[20] = "greenBeans";
vegetables[21] = "greenOnions";
vegetables[22] = "hotPeppers";
vegetables[23] = "kale";
vegetables[24] = "kohlrabi";
vegetables[25] = "leeks";
vegetables[26] = "lettuce";
vegetables[27] = "mushrooms";
vegetables[28] = "mustardGreens";
vegetables[29] = "okra";
vegetables[30] = "onions";
vegetables[31] = "parsnips";
vegetables[32] = "peas";
vegetables[33] = "potatoes";
vegetables[34] = "pumpkins";
vegetables[35] = "radish";
vegetables[36] = "rutabagas";
vegetables[37] = "saladGreens";
vegetables[38] = "saladMix";
vegetables[39] = "seaVegetables";
vegetables[40] = "shallots";
vegetables[41] = "spinach";
vegetables[42] = "summerSquash";
vegetables[43] = "sunchokes";
vegetables[44] = "sweetPeppers";
vegetables[45] = "sweetPotato";
vegetables[46] = "swissChard";
vegetables[47] = "tomatillos";
vegetables[48] = "tomatoes";
vegetables[49] = "turnips";
vegetables[50] = "winterSquash";
vegetables[51] = "zucchini";