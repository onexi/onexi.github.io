
var http = require('http');
var url = require('url') ;
var fs = require('fs');
var filename = '';

var s = http.createServer(function(req,res){

	var headers = {};
	headers["Access-Control-Allow-Origin"] = "*";
	headers["Access-Control-Allow-Methods"] = "POST, GET, PUT, DELETE, OPTIONS";
	headers["Access-Control-Allow-Headers"] = "X-Requested-With, X-HTTP-Method-Override, Content-Type, Accept";
	res.writeHead(200, headers);

	try{
		// get query string student data
		var queryObject = url.parse(req.url,true).query;
		var firstName   = queryObject.firstName;
		var lastName    = queryObject.lastName;
		var department  = queryObject.department;
		var email       = queryObject.email;

		// create a student object
		var student = {
			firstName  : firstName,
			lastName   : lastName,
			department : department,
			email      : email
		};
		student = JSON.stringify(student);

		filename = firstName + lastName + '.json';
		filename = "data/" + filename;

		fs.writeFile(filename, student, function(err) {
			if(err) {
				console.log(err);
			} else {
				console.log("The file " + filename + " was saved!");
			}
		});

	}
	catch(e){
		console.log(e.message);
	}

	res.end('saved ' + filename);
});

s.listen(8000);