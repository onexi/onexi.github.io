
var http = require('http');
var url = require('url') ;
var fs = require('fs');
var file = '';

var s = http.createServer(function(req,res){

	var headers = {};
	headers["Access-Control-Allow-Origin"] = "*";
	headers["Access-Control-Allow-Methods"] = "POST, GET, PUT, DELETE, OPTIONS";
	headers["Access-Control-Allow-Headers"] = "X-Requested-With, X-HTTP-Method-Override, Content-Type, Accept";
	res.writeHead(200, headers);

	try{
		// get query string weather data
		var queryObject   = url.parse(req.url,true).query;
		var temperature   = queryObject.temperature;
		var precipitation = queryObject.precipitation;
		var humidity      = queryObject.humidity;
		var wind          = queryObject.wind;

		// create a weather object
		var weather = {
			temperature  : temperature,
			precipitation: precipitation,
			humidity     : humidity,
			wind         : wind
		};
		weather = JSON.stringify(weather);

		filename = new Date().getTime().toString() + '.json';
		filename = "data/" + filename;

		fs.writeFile(filename, weather, function(err) {
			if(err) {
				console.log(err);
			} else {
				console.log("The file " + filename + " was saved!");
			}
		});

	}
	catch(e){
		console.log(e.message);
	}

	res.end('saved ' + filename);

});

s.listen(8000);