var webSocketServer = require('ws').Server; 
var wss = new webSocketServer({port: 8080});

// broadcast client message to all
wss.broadcast = function broadcast(data) {
  wss.clients.forEach(function each(client) {
    client.send(data);
  });
};

// catch client messages
wss.on('connection', function connection(ws) {
  ws.on('message', function incoming(message) {
    console.log('received from %s', message);
    wss.broadcast(message);    
  });
});
