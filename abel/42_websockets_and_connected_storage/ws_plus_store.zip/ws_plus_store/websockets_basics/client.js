var webSocketClient = require('ws');
var ws = new webSocketClient('ws://localhost:8080');

ws.on('message', function(message) {
     console.log('received from %s', message);
});

function sendMessage(){
    ws.send((new Date()).toString());
}

function timer(){
	sendMessage();
	setTimeout(timer, 20000);
}

ws.on('open', function() {
	timer();
});
