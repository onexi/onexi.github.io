var webSocketClient = require('ws');
var ws = new webSocketClient('ws://localhost:8080');
var id = Math.floor(Math.random()*10000);

ws.on('message', function(message) {
     console.log('received from %s', message);
});

function sendMessage(){
    var message = '<img src="http://geospatial.mit.edu/images/mit.png">';
    ws.send(message);
}

function timer(){
	sendMessage();
	setTimeout(timer, 20000);
}

ws.on('open', function() {
	timer();
});
