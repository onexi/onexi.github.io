var data = "My name is <b>Bo</b>, I'm <b>18</b> years old, I like <b>code</b>.";

// -------------------------------------------------------
//   YOUR CODE
// get text between bold tags using a regular expression
// -------------------------------------------------------