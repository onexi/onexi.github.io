function gogogo() {
    alert("Yay, it works!");
}