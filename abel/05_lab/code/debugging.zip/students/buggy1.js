// buggy JS #1

function gogogo() {
    alert("Yay, it works!");
}