function gogogo(); {
    Alert("Yay, it works!'');
)