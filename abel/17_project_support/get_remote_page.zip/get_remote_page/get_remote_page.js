var request = require("request");

var inspectHtml = function(html) {
    console.log(html);
};

var url = "http://www.mit.edu/index.html";
request(url, function (error, response, body) {
    if (!error) {
        inspectHtml(body);
    } else {
        console.log(error);
    }
});