var express     = require('express');
var app         = express();

app.all('/*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
});

app.get('/', function(req, res){ 
    res.send('Hello World!');
});

// return JSON object
app.get('/getUser', function(req, res){ 

    var user = {
        'firstName' : 'peter', 
        'lastName'  : 'parker',
        'email'     : 'peter@mit.edu'          
    };
    res.send(user);
});


// start server
app.listen(3000);