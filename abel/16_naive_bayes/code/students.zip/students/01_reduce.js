var words = ['hi','boo','boo','hello','ada','ada','ada'];

// ------------------------------------------
//  YOUR CODE
//  Calculate word frequency
// ------------------------------------------