var frequency = require('./frequency');
var words     = ['hi','boo','boo','hello','ada','ada','ada'];
var result    = {hi: 1, boo: 2, hello: 1, ada: 3}

// ------------------------------------------
//  YOUR CODE
//  test word frequency
// ------------------------------------------