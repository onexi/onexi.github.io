// ------------------------------------------
//  YOUR CODE
//  Write sum(a,b) function
//  Share using module.exports
// ------------------------------------------