var tokenize = require('./tokenize');

var document = 'El ex presidente sudafricano, Nelson Mandela, ha sido hospitalizado la tarde del sábado, según confirmó un hospital de Pretoria a CNN. Al parecer se trata de un chequeo médico que ya estaba previsto, relacionado con su avanzada edad, según explicó el portavoz de la presidencia Sudafricana Mac Maharaj.';

var solution = [ 'el', 'ex', 'presidente', 'sudafricano', 'nelson', 'mandela', 'ha', 'sido', 'hospitalizado', 'la', 'tarde', 'del', 'sabado', 'segun', 'confirmo', 'un', 'hospital', 'de', 'pretoria', 'a', 'cnn', 'al', 'parecer', 'se', 'trata', 'chequeo', 'medico', 'que', 'ya', 'estaba', 'previsto', 'relacionado', 'con', 'su', 'avanzada', 'edad', 'explico', 'portavoz', 'presidencia', 'sudafricana', 'mac', 'maharaj' ];

test('tokenized document equal to solution', () => {
  expect(tokenize(document)).toEqual(solution);
});