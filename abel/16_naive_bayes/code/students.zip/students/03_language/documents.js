// keep track of documents per language
var documents = { languages : {
    french  : 0,
    spanish : 0,
    english : 0,
    german  : 0,
    basque  : 0
}};

// increment document count
documents.add = function(language){
    documents.languages[language] += 1;
}

documents.count = function(language){
    return documents.languages[language];
}

var notInCount;
documents.run = function (){
    var count = 0;
    for(var language in documents.languages){
        // console.log(language);
        count += documents.languages[language];
    }
    // console.log('count: ' + count);    

    var obj = {};
    for(var language in documents.languages){
        obj[language] = count - documents.languages[language];
    }
    // console.log(obj);
    notInCount = obj;
}
documents.notInCount = function(language){
    return notInCount[language];
};

module.exports = documents;
