var words = require('./words');

// sample data
var sample        = {};
sample.banana     = {english: 2,french: 1,spanish: 2};
sample.restaurant = {english: 1,french: 2,spanish: 1};

// populate with words and languages
words.add('banana','spanish');
words.add('banana','spanish');
words.add('banana','french');
words.add('banana','english');
words.add('banana','english');
words.add('restaurant','english');
words.add('restaurant','french');
words.add('restaurant','french');
words.add('restaurant','spanish');

test('banana equal to word counts', () => {
  expect(words.banana).toEqual(sample.banana);
});

test('restaurant equal to word counts', () => {
  expect(words.restaurant).toEqual(sample.restaurant);
});
