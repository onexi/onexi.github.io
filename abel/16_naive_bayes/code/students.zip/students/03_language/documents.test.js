
// testing documents
// ----------------------
var documents = require('./documents');
for (var i = 0; i < 5; i++) {
    documents.add('french');
    documents.add('spanish');
    documents.add('english');
    documents.add('german');    
    documents.add('basque');    
}
// console.log(documents);
// var temp = documents.notInCount();
// console.log(temp);
// console.log(documents);

var languages = { french: 5, spanish: 5, english: 5, german: 5, basque: 5 };
documents.run();

test('languages document counts verification', () => {
  expect(documents.languages).toEqual(languages);
});

test('document count not spanish is 20', () => {
  expect(documents.notInCount('spanish')).toBe(20);
});
