// data structure
// ----------------------------------------------
// var words = {
// 	banana    : { english: 5, french: 4, spanish: 4} , 
// 	restaurant: { english: 4, french: 3, spanish: 2}
// };


var words = {
};

words.add = function(word,language){

    if(word in words){
        if(language in words[word]){
            words[word][language] += 1;
        }
        else{
            words[word][language] = 1;
        }
    } 
    else{
        words[word] = {};
        words[word][language] = 1;
    }
}

words.count = function(word){    
    var count = 0;
    if(words[word]){
        var languages = words[word];
        for(language in languages){
            count += languages[language];
        }
    } 
    return count;
}


words.countInLanguage = function(word,language){    
    var count = 0;
    if(words[word]){
        if (words[word][language]){
            return words[word][language];
        }
    } 
    return count;
}

words.countNotInLanguage = function (word, language) {
    var count = 0;
    if(words[word]){
        var languages = words[word];
        for (var item in languages){
            if (item === language) continue;
            count += languages[item];
        }
    } 
    return count;
};

module.exports = words;

















