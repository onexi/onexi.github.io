
// // testing tokenize
// // ----------------------
// var tokenize = require('./tokenize');
// var document = 'El ex presidente sudafricano, Nelson Mandela, ha sido hospitalizado la tarde del sábado, según confirmó un hospital de Pretoria a CNN. Al parecer se trata de un chequeo médico que ya estaba previsto, relacionado con su avanzada edad, según explicó el portavoz de la presidencia Sudafricana Mac Maharaj.';
// var tokenized = tokenize(document);
// console.log(tokenized);


// // testing words
// // ----------------------
// var words = require('./words');
// words.add('banana','spanish');
// words.add('banana','spanish');
// words.add('banana','french');
// words.add('banana','english');
// words.add('banana','english');
// words.add('restaurant','english');
// words.add('restaurant','french');
// words.add('restaurant','french');
// words.add('restaurant','spanish');
// console.log(words);

// console.log(words.count('restaurant'));
// console.log(words.countInLanguage('banana','spanish'));
// console.log(words.countNotInLanguage('banana','french'));


// // testing documents
// // ----------------------
// var documents = require('./documents');
// for (var i = 0; i < 5; i++) {
// 	documents.add('french');
// 	documents.add('spanish');
// 	documents.add('english');
// 	documents.add('german');	
// 	documents.add('basque');	
// }

// // create document counts
// documents.run();
// var temp = documents.notInCount('spanish');
// console.log('temp: ' + temp);
// console.log(documents);


















