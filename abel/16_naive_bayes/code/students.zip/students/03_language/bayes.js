var tokenize  = require('./tokenize');
var words     = require('./words');
var documents = require('./documents');
var data      = require('./data');

// process training documents
var train = function (document, language) {

    // increment document language count
    documents.add(language);

    // extract word array from document
    var tokens = tokenize(document);
    var length = tokens.length;

    // add to word totals
    tokens.forEach(function(word){
        words.add(word, language);        
    })
};


function calculateProbability(word,language){

    // probability that word shows up in a language
    // e.g. the probability that "bonjour" shows up in a French document
    var wordProbability = words.countInLanguage(word, language) / documents.count(language);

    // probability that word is not in language
    var wordNotProbability = words.countNotInLanguage(word, language) / documents.notInCount(language);

    // probability that document is in a "language" given that "word" is in it
    // e.g. probability that document is french given that "bonjour" is in it
    // http://en.wikipedia.org/w/index.php?title=Naive_Bayes_spam_filtering#Computing_the_probability_that_a_message_containing_a_given_word_is_spam
    var probability = wordProbability / (wordProbability + wordNotProbability);

    // avoid 0 and 1 for later log calculations
    if (probability === 0) probability = 0.01;
    else if (probability === 1) probability = 0.99;
    return probability;    
}

function run(text){
    // train using newspaper articles in data
    data.training.forEach(function(article){
        train(article.text, article.language);
    })

    // create document counts
    documents.run();

    // get string tokens - word array
    var tokens      = tokenize(text);
    var scores      = {};    
    var probability = 0;

    // loop though languages in documents
    for(var language in documents.languages){

        // stores the probability of document in language
        var logSum = 0;        
       
        // loop through the words in the input text
        tokens.forEach(function(word){
            // instaces of the word across all languages
            var _wordTotalCount = words.count(word);

            // if zero, no info on word, jump to next loop iteration
            if (_wordTotalCount === 0) { return; } 

            // calculate probability
            probability = calculateProbability(word,language);
       
            // Underflow Prevention
            // http://en.wikipedia.org/wiki/Naive_Bayes_spam_filtering#Other_expression_of_the_formula_for_combining_individual_probabilities
            logSum += (Math.log(1 - probability) - Math.log(probability));

            // debugging feedback
            // console.log(language + "icity of " + word + ": " + probability + ", logSum: " + logSum);
        });
        scores[language] = 1 / ( 1 + Math.exp(logSum) );
    }
    //displayPretty(scores);    
    return scores;
}

console.log(run('es ist gut'));














