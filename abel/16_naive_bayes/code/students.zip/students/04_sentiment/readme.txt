Reviews from:
http://www.cs.cornell.edu/people/pabo/movie-review-data/

Dataset used:
sentence polarity dataset

To get word stems, we used the "Porter Stemmer" algorithm. There is a JavaScript implementation here:
https://github.com/kristopolous/Porter-Stemmer