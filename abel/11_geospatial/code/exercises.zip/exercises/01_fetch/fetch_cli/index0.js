var fetch = require('node-fetch');

var url = 'https://onexi.org/data/users.json';

// ------------------------------------
//	YOUR CODE
//	Use fetch to request url data
// ------------------------------------

