var fetch = require('node-fetch');

var apiKey = 'cd44503873bb4cab99f83ef6743e3c5e';
var headlines = 'https://newsapi.org/v2/top-headlines?country=us&apiKey=' + apiKey;

async function fetchNews(){
	// ------------------------------------
	//	YOUR CODE
	//	1 - Use fetch to request headlines
	//  2 - Use await, loop through reponse
	//  3 - Write items to console
	// ------------------------------------
}
fetchNews();