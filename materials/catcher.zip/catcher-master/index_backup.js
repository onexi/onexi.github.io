require('shelljs/global');
var express     = require('express');
var MongoClient = require('mongodb').MongoClient;
var fs          = require('fs'); 
var app         = express();

// connect to mongo
var url = 'mongodb://sender:pigwigbig@store.onexi.org:27017/exercises';
var db;
MongoClient.connect(url, function (err, database) {
    if(err){ console.log('failed to connect: ' + err); return;}
    db = database;
    console.log("Connected correctly to server!!");
});

// setup config for post submissions
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


// process posted data 
app.use(function (req, res) {

    // check for a bad payload
    function badPayload(webhook){
        if(webhook){
            if(!webhook.hasOwnProperty("pull_request")){ return true;}
            if(!webhook.hasOwnProperty("repository"))  { return true;}
            return false;
        }
        else{ return true;}
    }

    try {

        // parse data
        res.setHeader('Content-Type', 'text/plain');
        res.write('you posted:\n');
        res.end(JSON.stringify(req.body, null, 2));

        //=================================================
        // Does running this block in a function 
        // create a protected memory.
        // I think so, the variables would be 
        // created and destroyed :)
        //=================================================        

        // validate data, exit if bad data
        var webhook = JSON.parse(req.body.payload);
        if (badPayload(webhook)){ 
            throw new Error('Payload data validation failed');
        }

        // clone student repository
        var studLogin    = webhook.pull_request.head.repo.owner.login;    
        var studRepoUrl  = webhook.pull_request.head.repo.ssh_url;
        var studRepoName = webhook.pull_request.head.repo.name;
        rm('-rf', studRepoName);        
        exec('git clone ' + studRepoUrl);    

        // clone base repository    
        var baseRepoUrl  = webhook.repository.ssh_url;
        var baseRepoId   = webhook.pull_request.base.repo.id;
        var baseRepoName = Date.now().toString();
        rm('-rf', baseRepoName);
        exec('git clone ' + baseRepoUrl + ' ' + baseRepoName);

        // validate student folder, exit if missing
        if (!fs.existsSync(studRepoName + '/' + studLogin)){ 
            rm('-rf', baseRepoName);            
            throw new Error('No student folder');
        } 

        // overwrite student test folder
        var studRepoTestPath = studRepoName + '/' + studLogin + '/test';
        var baseRepoTestPath = baseRepoName + '/starter_code/test'; 
        rm('-rf', studRepoTestPath);
        cp('-r' , baseRepoTestPath, studRepoTestPath);

        // move into folder, modify test string command, and test
        cd(studRepoName + '/' + studLogin);
        sed('-i', '"test": "mocha"', '"test": "mocha test -R json > test/test.json"', 'package.json');    
        exec('npm install');
        exec('npm test');

        // validate test results, exit if test.json missing
        if (!fs.existsSync('test/test.json')){ 
            throw new Error('No ouput, test.json missing');
        }     

        // write webhook data to test results file, plus time stamp 
        var fileName = 'test/test.json';
        var data = JSON.parse(fs.readFileSync(fileName, 'utf8'));
        data.webhook = webhook;
        data.timestamp = (new Date()).toString();
        data.timestampnumber = (Date.now()).toString();

        // ------ used for debugging ------ 
        // fs.writeFileSync(fileName, JSON.stringify(data, null, 2));    
        // exec('curl -H "Content-Type: application/json" --data @test/test.json http://arlington3.mit.edu:3000/');

        // write to mongo
        var exercises = db.collection('exercise'+baseRepoId);
        exercises.insert(data, {w:1}, function(err, result) {
            cd('../..');
            rm('-rf', baseRepoName);
            rm('-rf', studRepoName);        
            console.dir(result);
        });      

    } catch (e) {
        console.error(e);  

        // prepare message
        var error = {};
        error.stack = e.stack;
        error.message = e.message;
        error.timestamp = (new Date()).toString();
        error.timestampnumber = (Date.now()).toString();
        
        // write to mongo
        var errors = db.collection('errors');
        errors.insert(error, {w:1}, function(err, result) {
            console.dir(result);
        });    
    }
});


// start server
var port = 3000;
console.log('Running on: ' + port);
app.listen(port);