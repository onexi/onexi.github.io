require('shelljs/global');
var express     = require('express');
var bodyParser  = require('body-parser');
var MongoClient = require('mongodb').MongoClient;
var fs          = require('fs'); 
var app = express();

var url = 'mongodb://sender:pigwigbig@104.236.230.207:27017/exercises';
var db;

MongoClient.connect(url, function (err, database) {
    if(err){ console.log('failed to connect: ' + err); return;}
    db = database;
    console.log("Connected correctly to server!!");
});

// parse application/x-www-form-urlencoded 
app.use(bodyParser.urlencoded({ extended: false }));
 
// parse application/json 
app.use(bodyParser.json());
 
app.use(function (req, res) {

  // check for a bad payload
  function badPayload(webhook){
    if(webhook){
      if(!webhook.hasOwnProperty("pull_request")){ return true;}
      if(!webhook.hasOwnProperty("repository"))  { return true;}
      return false;
    }
    else{ return true;}
  }

  try {

    // parse data
    res.setHeader('Content-Type', 'text/plain');
    res.write('you posted:\n');
    res.end(JSON.stringify(req.body, null, 2));

    // validate data
    var webhook = JSON.parse(req.body.payload);
    if (badPayload(webhook)) {return;}

    // clone student repository
    var studLogin    = webhook.pull_request.head.repo.owner.login;    
    var studRepoUrl  = webhook.pull_request.head.repo.ssh_url;
    var studRepoName = webhook.pull_request.head.repo.name;
    rm('-rf', studRepoName);        
    exec('git clone ' + studRepoUrl);    

    // clone base repository    
    var baseRepoUrl  = webhook.repository.ssh_url;
    var baseRepoId   = webhook.pull_request.base.repo.id;
    var baseRepoName = Date.now().toString();
    rm('-rf', baseRepoName);
    exec('git clone ' + baseRepoUrl + ' ' + baseRepoName);

    // overwrite student test folder
    var studRepoTestPath = studRepoName + '/' + studLogin + '/test';
    var baseRepoTestPath = baseRepoName + '/starter_code/test'; 
    rm('-rf', studRepoTestPath);
    cp('-r' , baseRepoTestPath, studRepoTestPath);

    // move in to folder, modify test string command, and test
    cd(studRepoName + '/' + studLogin);
    sed('-i', '"test": "mocha"', '"test": "mocha test -R json > test/test.json"', 'package.json');    
    exec('npm install');
    exec('npm test');

    // write webhook data to test results file, plus time stamp 
    var fileName = 'test/test.json';
    var data = JSON.parse(fs.readFileSync(fileName, 'utf8'));
    data.webhook = webhook;
    data.timestamp = (new Date()).toString();
    data.timestampnumber = (Date.now()).toString();

    // ------ use for debugging ------ 
    // fs.writeFileSync(fileName, JSON.stringify(data, null, 2));    
    // exec('curl -H "Content-Type: application/json" --data @test/test.json http://arlington3.mit.edu:3000/');

    // write to mongo
    var exercises = db.collection('exercise'+baseRepoId);
    exercises.insert(data, {w:1}, function(err, result) {
        cd('../..');
        rm('-rf', baseRepoName);
        rm('-rf', studRepoName);        
        console.dir(result);
    });      

  } catch (e) {
    console.error('error on doc access: ' + e);  	
    var errors = db.collection('errors');
    errors.insert(e.message, {w:1}, function(err, result) {
        console.dir(result);
    });          
  }

});


// start server
var port = 80;
console.log('Running on: ' + port);
app.listen(port);