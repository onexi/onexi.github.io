require('shelljs/global');
var express     = require('express');
var fs          = require('fs'); 
var app         = express();
var request     = require('request');

// address to post data
var url = 'http://store.onexi.org/';

// setup config for post submissions
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// process posted data 
app.post('/', function(req, res){

    // check for a bad payload
    function badPayload(webhook){
        if(webhook){
            if(!webhook.hasOwnProperty("pull_request")){ return true;}
            if(!webhook.hasOwnProperty("repository"))  { return true;}
            return false;
        }
        else{ return true;}
    }

    function deleteDir(){
        var length = arguments.length;
        for(var i=0; i<length; i++){
            rm('-rf', arguments[i]);
        }
    }

    function badJson(path) {
        try {
            JSON.parse(fs.readFileSync(fileName, 'utf8'));
        } catch (e) {
            return true;
        }
        return false;
    }


    try {
        // send posted information back for debugging
        res.end(JSON.stringify(req.body, null, 2));

        // validate data, exit if bad data
        var webhook = JSON.parse(req.body.payload);
        if (badPayload(webhook)){ 
            throw new Error('Payload data validation failed');
        }

        // clone student repository
        var studLogin    = webhook.pull_request.head.repo.owner.login;    
        var studRepoUrl  = webhook.pull_request.head.repo.ssh_url;
        var studRepoName = webhook.pull_request.head.repo.name;
        deleteDir(studRepoName);
        exec('git clone ' + studRepoUrl);    

        // clone base repository    
        var baseRepoUrl  = webhook.repository.ssh_url;
        var baseRepoId   = webhook.pull_request.base.repo.id;
        var baseRepoName = Date.now().toString();
        deleteDir(baseRepoName);
        exec('git clone ' + baseRepoUrl + ' ' + baseRepoName);

        // validate student folder, exit if missing
        if (!fs.existsSync(studRepoName + '/' + studLogin)){ 
            deleteDir(studRepoName,baseRepoName);
            throw new Error('No student folder');
        } 

        // overwrite student test folder
        var studRepoTestPath = studRepoName + '/' + studLogin + '/test';
        var baseRepoTestPath = baseRepoName + '/starter_code/test'; 
        deleteDir(studRepoTestPath);
        cp('-r' , baseRepoTestPath, studRepoTestPath);

        // move into folder, exit if package.json missing
        cd(studRepoName + '/' + studLogin);        
        var fileName = 'package.json';
        if (!fs.existsSync(fileName)){ 
            deleteDir(studRepoName, baseRepoName);
            throw new Error('File package.json missing');
        }     

        // modify test string command, remove devDependencies
        var data = JSON.parse(fs.readFileSync(fileName, 'utf8'));
        data.scripts.test = 'mocha test -R json > test/test.json';
        delete data.devDependencies;                        
        fs.writeFileSync(fileName, JSON.stringify(data, null, 2));

        // handle console logs in mocha tests
        exec('echo "console.log = function() {};" > test/test.back',{silent:true});
        exec('cat test/test.js >> test/test.back',{silent:true});
        exec('rm test/test.js',{silent:true});
        exec('mv test/test.back test/test.js',{silent:true});

        // install dependencies and run test
        exec('npm install',{silent:true});
        exec('npm test',{silent:true});

        // validate test results, exit if test.json missing
        fileName = 'test/test.json';        
        if (!fs.existsSync(fileName)){
            cd('../..'); 
            deleteDir(studRepoName, baseRepoName);
            throw new Error('No ouput, test.json missing');
        }     


        if (badJson(fileName)){
            cd('../..');             
            deleteDir(studRepoName, baseRepoName);
            throw new Error('Invalid json in test.json');
        }

        // add webhook and time stamp to data
        data = JSON.parse(fs.readFileSync(fileName, 'utf8'));
        data.webhook = webhook;
        data.timestamp = (new Date()).toString();
        data.timestampnumber = (Date.now()).toString();
        data.id = baseRepoId; 
        data.login = studLogin;
        data.name = studRepoName;
        data.ip = process.env.IPHOST;
        data.collection = 'exercise' + baseRepoId;

        // ------ used for debugging ------ 
        // fs.writeFileSync(fileName, JSON.stringify(data, null, 2));    
        // exec('curl -H "Content-Type: application/json" --data @test/test.json http://arlington3.mit.edu:3000/');

        // clean up - delete repos
        cd('../..');
        deleteDir(baseRepoName, studRepoName);

        // post data
        request.post(url, {form:data});

    } catch (e) {
        console.error(e);  

        // prepare message
        var error = {};
        error.stack = e.stack;
        error.message = e.message;
        error.timestamp = (new Date()).toString();
        error.timestampnumber = (Date.now()).toString();
        error.collection = 'exerciseErrors';
        
        // post data        
        request.post(url, {form:error});  
    }
});


// start server
var port = 3000;
console.log('Running on: ' + port);
app.listen(port);