var express = require('express');
var app     = express();

app.get('/', function(req,res){
    var queryString = req.query;
    console.log(queryString);
    res.send(queryString);
});

app.listen(3000,function(){
    console.log('listening on port 3000');
});

// Test with
// curl "localhost:3000?name=cloe&age=5&nickname=funny"