var express = require('express');
var app     = express();

app.get('/getUser/:id', function(req, res){ 
    res.send(req.params.id);
});

app.get('/user/:name/:id', function(req, res){ 
    res.send(req.params.id + req.params.name);
});

app.listen(3000, function(){
    console.log('Server running on port 3000');
});