var express = require('express');
var app     = express();
app.use(express.static('public'));

// used for form submissions
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

/* GET Registration Page */
app.get('/', function(req, res){
	res.redirect('/signup.html');
});

/* Handle Registration POST - 
   body-parser needed to parse form */
app.post('/signup', function(req, res){
	var message = {
        "username" : req.body.username, 
        "password" : req.body.password
    };
    console.log(req.body);    
    res.send(message);
});

app.listen(3000);