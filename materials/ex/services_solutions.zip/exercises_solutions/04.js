var express = require('express');
var app     = express();

var users = [
    { id : '01', name: 'john', email: 'john@mit.edu'},
    { id : '02', name: 'mary', email: 'mary@mit.edu'},
    { id : '03', name: 'paul', email: 'paul@mit.edu'},
    { id : '04', name: 'anna', email: 'anna@mit.edu'},
];

app.get('/getUser/:id', function(req, res){ 
    var id   = req.params.id;
    var user = users.find(function(obj){ return obj.id === id; });
    if(user) res.send(user);
    else res.send('User not found!');
});

app.get('/addUser/:id/:name/:email', function(req, res){ 
    var user = {
        id    : req.params.id,
        name  : req.params.name,
        email : req.params.email
    };
    users.push(user);
    res.send(users);
});


app.listen(3000, function(){
    console.log('Server running on port 3000');
});