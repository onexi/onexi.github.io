# sort an array from min value to max value
