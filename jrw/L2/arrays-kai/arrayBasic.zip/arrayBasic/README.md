# basic operaions on an array
