var exercise = require('./exercise.js');

var response = exercise.change();
console.log(response);

var response = exercise.length();
console.log(response);

var response = exercise.concatenate();
console.log(response);

var response = exercise.addToEnd();
console.log(response);

var response = exercise.addToBegin();
console.log(response);

var response = exercise.deleteLast();
console.log(response);

var response = exercise.deleteFirst();
console.log(response);

var response = exercise.insert();
console.log(response);

var response = exercise.concat();
console.log(response);

var response = exercise.sortAlphabetically();
console.log(response);

var response = exercise.reverseSort();
console.log(response);