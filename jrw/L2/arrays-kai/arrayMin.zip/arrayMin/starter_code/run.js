var exercise = require('./exercise.js');

var unordered = [11,2,15,4,5,20,7,17,13,10,1,12,9,14,3,16,8,18,19,6];
var response = exercise.min(unordered);

console.log(response);