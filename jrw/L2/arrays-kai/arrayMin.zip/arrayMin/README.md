# find the min value of an array
