var data = {
    contacts: [{
            name: 'john',
            email: 'jrw@mit.edu',
            courses: [
                '1.00', '1.125'
            ],
            hobbies: ['golf', 'tango']
        },
        {
            name: 'abel',
            email: 'abel@mit.edu',
            courses: [
                '1.00', '1.125'
            ],
            hobbies: ['basketball', 'guitar']
        },
        {
            name: 'nadia',
            email: 'nadia@mit.edu',
            courses: [
                '1.00', '6.001'
            ],
            hobbies: ['french', 'skydiving']
        },
        {
            name: 'isabella',
            email: 'isabella@mit.edu',
            courses: [
                '1.00', '15.131'
            ],
            hobbies: ['swimming', 'travel']
        }
    ]
};
