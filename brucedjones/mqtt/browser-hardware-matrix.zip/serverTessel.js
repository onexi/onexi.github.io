var mqtt = require('mqtt')
var tessel = require("tessel");
var backpack = require('backpack-ht16k33')

var grid = [[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]];

var client;
var matrix;

var startBackpack = function(){
    return new Promise(function(resolve,reject){
        matrix = backpack.use(tessel.port['B']);
        matrix.on('ready', function() {
            matrix.clear();
            console.log('Backpack on!')
            resolve();
        });
    })
}

var startMQTT = function(){
    return new Promise(function(resolve,reject){
        client = mqtt.connect('mqtt://162.243.219.88',1883)
        console.log('Connecting');
        client.on('connect', function () {
            console.log("Connected");
            client.subscribe('LEDMatrix/#');
            resolve();
        });
    });
}

startBackpack()
.then(startMQTT)
.then(function(){
    client.on('message', function (topic, message) {
        
        var path = topic.split('/');
        var index = Number(path[1]);
        var row = Math.floor(index/8);
        var col = index%8;
        var state = JSON.parse(message.toString());
        grid[row][col] = Number(state);
        client.publish('Matrix',JSON.stringify(grid));
        
        matrix.writeBitmap(grid);
    })
})