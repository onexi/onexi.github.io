var mqtt = require('mqtt')
var tessel = require("tessel");
var matrix = require('backpack-ht16k33').use(tessel.port['B']);
var ambient = require('ambient-attx4').use(tessel.port['A']);

var grid = [[0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0]];

var client;

var startBackpack = function () {
    return new Promise(function (resolve, reject) {
        matrix.on('ready', function () {
            matrix.clear();
            console.log('Backpack on!')
            resolve();
        });
    })
}

var startAmbient = function () {
    return new Promise(function (resolve, reject) {
        ambient.on('ready', function () {
            console.log('Ambient on!')
            resolve();
        });
    })
}

var startMQTT = function () {
    return new Promise(function (resolve, reject) {
        client = mqtt.connect('mqtt://162.243.219.88', 1883)
        console.log('Connecting');
        client.on('connect', function () {
            console.log("Connected");
            client.subscribe('LEDMatrix/#');
            resolve();
        });
    });
}

startBackpack()
    .then(startAmbient)
    .then(startMQTT)
    .then(function () {

        client.on('message', function (topic, message) {
            // console.log(message.toString())
            var path = topic.split('/');
            var index = Number(path[1]);
            var row = Math.floor(index / 8);
            var col = index % 8;
            var state = JSON.parse(message.toString());
            grid[row][col] = Number(state);
            client.publish('Matrix', JSON.stringify(grid));
            //matrix.clear();
            matrix.writeBitmap(grid);
        })

        setInterval(function () {
            ambient.getLightLevel(function (err, lightdata) {
                if (err) console.log(err);
                ambient.getSoundLevel(function (err, sounddata) {
                    if (err) console.log(err);
                    var data = { date: new Date(), soundLevel: sounddata, lightLevel: lightdata };
                    client.publish('ambientData', JSON.stringify(data));
                    console.log(JSON.stringify(data));
                });
            });
        }, 5000);
    })